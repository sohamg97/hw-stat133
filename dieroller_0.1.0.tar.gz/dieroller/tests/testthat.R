# Title: testthat.R
# Description: Run test function
# Input(s): code
# Output(s): testing to check if function runs
# Author(s): Soham Ghosh
# Date: 04-27-2018

library(testthat)
library(dieroller)

test_check("dieroller")
