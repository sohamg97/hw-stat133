# Title: test-roll.R
# Description: Test roll function
# Input(s): code
# Output(s): testing to check if roll function runs
# Author(s): Soham Ghosh
# Date: 04-27-2018

context("Check roll arguments")

test_that("check_times with ok values", {
  expect_true(check_times(1))
  expect_true(check_times(2))
  expect_true(check_times(3))
})

test_that("check_times with not ok values", {
  expect_error(check_times("a"),"\nargument 'times' must be a positive integer")
  expect_error(check_times(-1),"\nargument 'times' must be a positive integer")
  expect_error(check_times(NA),"\nargument 'times' must be a positive integer")
})

test_that("roll works with valid parameters", {

  a = die(c(7,2,3,4,5,6),c(2/6,0/6,3/12,1/12,1/6,1/6))
  set.seed(1)
  b = roll(a,50)
  expect_equal(b[1],7)
})

test_that("roll works with valid parameters", {

  a = die(c(7,2,3,4,5,6),c(2/6,0/6,3/12,1/12,1/6,1/6))
  set.seed(1)
  b = roll(a,10)
  expect_equal(b$rolls,c(7,3,3,5,7,5,4,6,6,7))
})

test_that("indexing works with valid parameters", {

  a = die(c(7,2,3,4,5,6),c(2/6,0/6,3/12,1/12,1/6,1/6))
  set.seed(1)
  b = roll(a,10)
  expect_equal(b[3], 3)
})

test_that("replacing works with valid parameters", {

  a = die(c(7,2,3,4,5,6),c(2/6,0/6,3/12,1/12,1/6,1/6))
  set.seed(1)
  b = roll(a,10)
  b[10] = 3
  #print(b$rolls)
  expect_equal(b[10],3)
})

test_that("add works with valid parameters", {

  a = die(c(7,2,3,4,5,6),c(2/6,0/6,3/12,1/12,1/6,1/6))
  set.seed(1)
  b = roll(a,10)
  #print(b$rolls)
  c = b + 5
  expect_equal(c[11:15],c(7,7,6,3,5))
  #c

  #print(b$rolls)
  #expect_error()
})

